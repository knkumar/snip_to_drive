var DOCLIST_SCOPE = 'https://docs.google.com/feeds';
var DOCLIST_FEED = DOCLIST_SCOPE + '/default/private/full/';
var google = new OAuth2('google', {
    client_id: '320704225509.apps.googleusercontent.com',
    client_secret: 'e8ZjN5PNLTHxM4AX3QQngyJw',
    api_scope: DOCLIST_SCOPE
});
